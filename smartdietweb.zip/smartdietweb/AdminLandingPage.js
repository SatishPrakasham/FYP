import { doc, getDoc } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore.js";
import { db } from './firebase-config.js'; // Ensure the path is correct

console.log('AdminLandingPage.js loaded successfully.');

// References to input fields and login button
const emailInput = document.getElementById('etEmail');
const passwordInput = document.getElementById('etPassword');
const loginButton = document.getElementById('btnLogin');
const loginMessage = document.getElementById('loginMessage');

// Add click event listener for login button
loginButton.addEventListener('click', async () => {
  const email = emailInput.value.trim();
  const password = passwordInput.value.trim();

  if (email === '' || password === '') {
    loginMessage.textContent = 'Please fill in both fields.';
    return; // Stop further execution if fields are empty
  }

  try {
    // Get the admin user document from Firestore
    const adminDocRef = doc(db, 'admin', 'adminUser');
    const docSnap = await getDoc(adminDocRef);

    if (docSnap.exists()) {
      const adminData = docSnap.data();

      // Check if email and password match
      if (adminData.email === email && adminData.password === password) {
        loginMessage.textContent = 'Login successful! Redirecting...';
        console.log('Admin logged in:', email);

        // Redirect to dashboard
        setTimeout(() => {
          window.location.href = 'AdminHomepage.html';
        }, 1000);
      } else {
        loginMessage.textContent = 'Invalid email or password. Please try again.';
      }
    } else {
      loginMessage.textContent = 'Admin user not found.';
    }
  } catch (error) {
    console.error('Error during login:', error);
    loginMessage.textContent = 'An error occurred. Please try again.';
  }
});

