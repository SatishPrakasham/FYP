// firebase-config.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore.js";
import { getStorage } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-storage.js";

console.log('Firebase initialized.');

const firebaseConfig = {
    apiKey: "AIzaSyBbe22odCaIFMAKP7mt3UT9fSBwnXvtqR8",
    authDomain: "smartdietfyp.firebaseapp.com",
    projectId: "smartdietfyp",
    storageBucket: "smartdietfyp.appspot.com",
    messagingSenderId: "156177946621",
    appId: "1:156177946621:web:14a4130abdba5dae98ab94",
    measurementId: "G-9B1C1C67LB"
};

// Initialize Firebase, Firestore, and Storage
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app); // Firestore instance
export const storage = getStorage(app); // Storage instance
